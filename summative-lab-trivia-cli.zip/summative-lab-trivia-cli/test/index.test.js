// index.test.js
const { startGame, questions, displayQuestion, validateAnswer, promptUser } = require('summative-lab-trivia-cli/index.js');

// Mock console.log
console.log = jest.fn();

describe('Trivia Game', () => {
    describe('displayQuestion', () => {
        it('should display the question and options', () => {
            const question = questions[0];
            displayQuestion(question, 0);
            expect(console.log).toHaveBeenCalledWith("Question 1: What is the capital of Bangladesh?");
            expect(console.log).toHaveBeenCalledWith("1. Paris");
            expect(console.log).toHaveBeenCalledWith("2. Dhaka");
        });
    });

    describe('validateAnswer', () => {
        it('should return true for a correct answer', () => {
            const question = questions[0];
            const result = validateAnswer(question, 2); // Dhaka is option 2
            expect(result).toBe(true);
        });

        it('should return false for an incorrect answer', () => {
            const question = questions[0];
            const result = validateAnswer(question, 1); // Paris is option 1
            expect(result).toBe(false);
        });
    });

    describe('startGame', () => {
        it('should run the game without errors', () => {
            // Mock promptUser to simulate user input
            jest.spyOn(module.exports, 'promptUser')
                .mockReturnValueOnce('2') // Correct answer for first question
                .mockReturnValueOnce('3') // Correct answer for second question
                .mockReturnValueOnce('1'); // Correct answer for third question

            startGame();

            // Verify the final score
            expect(console.log).toHaveBeenCalledWith("Game over! Your final score is: 3/3");

            // Restore the original function
            jest.restoreAllMocks();
        });
    });
});